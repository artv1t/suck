#!/usr/bin/env node

console.log('🧪 Testing RaydiumService getPoolLiquidity method...');

async function testRaydiumLiquidity() {
  try {
    const { raydiumService } = await import('./dist/services/raydiumService.js');
    console.log('✅ RaydiumService imported');

    const poolAddress = 'test-pool-12345678';
    
    console.log('🔧 Testing getPoolLiquidity with timeout...');
    const startTime = Date.now();
    
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Liquidity test timeout after 4 seconds')), 4000);
    });
    
    // Access private method via reflection (hack for testing)
    const liquidityMethod = raydiumService.getPoolLiquidity || raydiumService.constructor.prototype.getPoolLiquidity;
    
    if (!liquidityMethod) {
      console.log('❌ Cannot access getPoolLiquidity method');
      return;
    }
    
    const result = await Promise.race([liquidityMethod.call(raydiumService, poolAddress), timeoutPromise]);
    
    const endTime = Date.now();
    console.log('✅ Liquidity result:', result);
    console.log('✅ Time taken:', endTime - startTime, 'ms');

  } catch (error) {
    console.log('❌ Liquidity error:', error.message);
    if (error.message.includes('timeout')) {
      console.log('❌ RaydiumService getPoolLiquidity is timing out!');
    }
    process.exit(1);
  }
}

testRaydiumLiquidity().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
