#!/usr/bin/env node

import { Connection, PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { Keypair } from '@solana/web3.js';

console.log('🔧 Testing startBalanceMonitoring() function...');

// Simulate the startBalanceMonitoring function
async function startBalanceMonitoring() {
  console.log('🔧 WalletManager: Starting balance monitoring...');
  
  try {
    // Create a test connection
    const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4', 'confirmed');
    console.log('✅ WalletManager: Connection created');
    
    // Create a test wallet
    const testWallet = Keypair.generate();
    console.log(`✅ WalletManager: Test wallet created: ${testWallet.publicKey.toString()}`);
    
    // Update balances immediately
    console.log('🔧 WalletManager: Updating balances immediately...');
    const balance = await getBalanceSafe(testWallet.publicKey.toString(), connection);
    const solBalance = balance / LAMPORTS_PER_SOL;
    console.log(`✅ WalletManager: Balance retrieved: ${solBalance} SOL`);
    
    // Set up periodic updates
    console.log('🔧 WalletManager: Setting up periodic balance updates...');
    const balanceUpdateInterval = setInterval(() => {
      console.log('🔧 WalletManager: Periodic balance update triggered');
      // In real implementation, this would call updateAllBalances()
    }, 30000); // Update every 30 seconds
    console.log('✅ WalletManager: Periodic balance updates set up (30s interval)');
    
    // Clear interval after 1 second for testing
    setTimeout(() => {
      clearInterval(balanceUpdateInterval);
      console.log('✅ WalletManager: Test completed, interval cleared');
    }, 1000);
    
  } catch (error) {
    console.error('❌ WalletManager: Balance monitoring setup failed:', error);
    throw error;
  }
}

// Simulate the getBalanceSafe function
async function getBalanceSafe(publicKey, connection) {
  try {
    console.log(`🔍 WalletManager: getBalanceSafe called for ${publicKey}...`);
    const pubkey = new PublicKey(publicKey);
    console.log(`🔍 WalletManager: PublicKey created: ${pubkey.toString()}`);
    console.log(`🔍 WalletManager: Connection endpoint: ${connection.rpcEndpoint}`);
    
    console.log(`🔍 WalletManager: Calling connection.getBalance...`);
    
    // Add timeout for getBalance
    const balancePromise = connection.getBalance(pubkey, 'confirmed');
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('getBalance timeout after 5 seconds')), 5000);
    });
    
    const balance = await Promise.race([balancePromise, timeoutPromise]);
    console.log(`✅ WalletManager: Balance retrieved: ${balance} lamports`);
    return balance;
  } catch (error) {
    console.error(`❌ WalletManager: Balance retrieval failed for ${publicKey}:`, error);
    throw error;
  }
}

// Test the function
async function test() {
  try {
    await startBalanceMonitoring();
    console.log('✅ Test completed successfully!');
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

test();
