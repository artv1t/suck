#!/usr/bin/env node

console.log('🚀 ЗАПУСК БОТА С ПРОВЕРКОЙ БАЛАНСА...');

async function testBalanceAndLaunch() {
  try {
    // Импортируем компоненты
    const { RPCManager } = await import('./dist/rpc/rpcManager.js');
    const { WalletManager } = await import('./dist/wallet/walletManager.js');
    const { BotManager } = await import('./dist/core/botManager.js');
    
    console.log('✅ Компоненты импортированы');

    // Создаем RPC Manager
    const rpcManager = new RPCManager();
    console.log('✅ RPC Manager создан');

    // Создаем Wallet Manager
    const walletManager = new WalletManager(rpcManager);
    console.log('✅ Wallet Manager создан');

    // Проверяем баланс кошелька
    console.log('💰 ПРОВЕРКА БАЛАНСА КОШЕЛЬКА...');
    const walletInfo = await walletManager.getPrimaryWallet();
    console.log('📊 Информация о кошельке:', walletInfo);

    // Получаем баланс SOL
    const solBalance = await walletManager.getTokenBalance('primary', 'So11111111111111111111111111111111111111112');
    console.log('💎 Баланс SOL:', solBalance, 'SOL');

    // Получаем метрики кошелька
    const walletMetrics = walletManager.getMetrics();
    console.log('📈 Метрики кошелька:', walletMetrics);

    // Создаем Bot Manager
    console.log('🤖 СОЗДАНИЕ BOT MANAGER...');
    const botManager = new BotManager();
    console.log('✅ Bot Manager создан');

    // Инициализируем бота
    console.log('🔄 ИНИЦИАЛИЗАЦИЯ БОТА...');
    await botManager.initialize();
    console.log('✅ Бот инициализирован');

    // Получаем метрики бота
    const botMetrics = botManager.getMetrics();
    console.log('📊 МЕТРИКИ БОТА:', botMetrics);

    // Запускаем бота
    console.log('🚀 ЗАПУСК БОТА...');
    await botManager.start();
    console.log('✅ Бот запущен и работает!');

    // Мониторинг в течение 30 секунд
    console.log('👀 МОНИТОРИНГ 30 СЕКУНД...');
    for (let i = 0; i < 30; i++) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      const currentMetrics = botManager.getMetrics();
      console.log(`⏱️  ${i+1}/30 сек - Активных позиций: ${currentMetrics.activePositions}`);
    }

    // Останавливаем бота
    console.log('🛑 ОСТАНОВКА БОТА...');
    await botManager.destroy();
    console.log('✅ Бот остановлен');

  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

testBalanceAndLaunch().then(() => {
  console.log('🏁 ТЕСТ ЗАВЕРШЕН');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
