#!/usr/bin/env node

console.log('🔧 ОБНОВЛЕНИЕ PHANTOM WALLET С ТВОИМ КОШЕЛЬКОМ...');

async function updatePhantomWallet() {
  try {
    const bs58 = await import('bs58');
    const fs = await import('fs');
    
    // Твой приватный ключ
    const privateKeyString = '3d1vESxeuEAGTQebx4LqT1UH1FysQtFsT397JBEzTHRfwADkp8ZsK39XAebGJJHACe4pZGs3JEBkgnPESxVtn9HC';
    
    console.log('🔑 Декодирование приватного ключа...');
    const privateKeyBytes = bs58.default.decode(privateKeyString);
    
    console.log('✅ Приватный ключ декодирован');
    console.log('📊 Длина байтов:', privateKeyBytes.length);
    
    // Конвертируем в массив чисел для JSON
    const privateKeyArray = Array.from(privateKeyBytes);
    
    console.log('💾 Сохранение в phantom-wallet.json...');
    fs.writeFileSync('./wallets/phantom-wallet.json', JSON.stringify(privateKeyArray, null, 2));
    
    console.log('✅ phantom-wallet.json обновлен!');
    console.log('🔑 Приватный ключ сохранен в правильном формате');
    
    // Проверяем файл
    const savedData = JSON.parse(fs.readFileSync('./wallets/phantom-wallet.json', 'utf8'));
    console.log('📊 Проверка сохраненного файла:');
    console.log('  📏 Длина массива:', savedData.length);
    console.log('  🔢 Первые 5 байтов:', savedData.slice(0, 5));
    console.log('  🔢 Последние 5 байтов:', savedData.slice(-5));
    
  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    process.exit(1);
  }
}

updatePhantomWallet().then(() => {
  console.log('🏁 ОБНОВЛЕНИЕ ЗАВЕРШЕНО');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
