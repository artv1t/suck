#!/usr/bin/env node

/**
 * PARTIAL BotManager Test
 * Tests BotManager initialization step by step to find the exact hang point
 */

console.log('🧪 Starting partial BotManager test...');
console.log('🧪 This will help identify the exact step causing the hang');

async function testBotManagerPartial() {
  try {
    console.log('🔧 Step 1: Importing BotManager...');
    const { BotManager } = await import('./src/core/botManager.js');
    console.log('✅ Step 1: BotManager imported successfully');

    console.log('🔧 Step 2: Creating BotManager instance (constructor only)...');
    const botManager = new BotManager();
    console.log('✅ Step 2: BotManager constructor completed successfully');

    console.log('🔧 Step 3: Testing BotManager status before initialize...');
    const statusBefore = botManager.getStatus();
    console.log('✅ Step 3: Status before initialize:', {
      running: statusBefore.running,
      totalEvents: statusBefore.totalEvents,
      memoryUsage: statusBefore.memoryUsage
    });

    console.log('🔧 Step 4: Calling initialize() method...');
    await botManager.initialize();
    console.log('✅ Step 4: BotManager initialize() completed successfully');

    console.log('🔧 Step 5: Testing BotManager status after initialize...');
    const statusAfter = botManager.getStatus();
    console.log('✅ Step 5: Status after initialize:', {
      running: statusAfter.running,
      totalEvents: statusAfter.totalEvents,
      memoryUsage: statusAfter.memoryUsage
    });

    console.log('🔧 Step 6: Testing getMetrics...');
    const metrics = botManager.getMetrics();
    console.log('✅ Step 6: Metrics obtained:', {
      bot: metrics.bot ? 'OK' : 'NULL',
      positions: metrics.positions ? 'OK' : 'NULL',
      trader: metrics.trader ? 'OK' : 'NULL',
      filters: metrics.filters ? 'OK' : 'NULL',
      wallets: metrics.wallets ? 'OK' : 'NULL',
      rpc: metrics.rpc ? 'OK' : 'NULL'
    });

    console.log('🔧 Step 7: Testing start() method...');
    await botManager.start();
    console.log('✅ Step 7: BotManager start() completed successfully');

    console.log('🔧 Step 8: Testing final status...');
    const finalStatus = botManager.getStatus();
    console.log('✅ Step 8: Final status:', {
      running: finalStatus.running,
      uptime: finalStatus.uptime,
      memoryUsage: finalStatus.memoryUsage
    });

    console.log('🔧 Step 9: Testing stop() method...');
    await botManager.stop();
    console.log('✅ Step 9: BotManager stop() completed successfully');

    console.log('✅ BotManager partial test completed successfully!');
    console.log('🎯 BotManager is NOT causing the hang');

  } catch (error) {
    console.error('❌ BotManager partial test failed:', error);
    console.log('🎯 BotManager IS causing the hang');
    console.log('🔍 Error details:', {
      name: error.name,
      message: error.message,
      stack: error.stack?.split('\n').slice(0, 5).join('\n')
    });
    process.exit(1);
  }
}

// Run the test
testBotManagerPartial().then(() => {
  console.log('🏁 Test completed, exiting...');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});