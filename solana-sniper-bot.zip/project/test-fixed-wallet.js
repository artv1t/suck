#!/usr/bin/env node

console.log('🔍 ТЕСТ ИСПРАВЛЕННОГО WALLET MANAGER...');

async function testFixedWallet() {
  try {
    const { Connection, PublicKey, Keypair } = await import('@solana/web3.js');
    const bs58 = await import('bs58');
    
    // Создаем прямое соединение с Helius
    const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4', 'confirmed');
    
    console.log('✅ Прямое соединение создано');
    console.log('🔗 RPC Endpoint:', connection.rpcEndpoint);
    
    // Загружаем phantom-wallet
    const fs = await import('fs');
    const phantomWalletData = JSON.parse(fs.readFileSync('./wallets/phantom-wallet.json', 'utf8'));
    const keypair = Keypair.fromSecretKey(new Uint8Array(phantomWalletData));
    
    console.log('✅ Phantom wallet загружен');
    console.log('🔑 Адрес:', keypair.publicKey.toString());
    
    // Получаем баланс напрямую
    console.log('💰 Получение баланса напрямую...');
    const balance = await connection.getBalance(keypair.publicKey, 'confirmed');
    const solBalance = balance / 1e9;
    
    console.log(`✅ Баланс: ${solBalance} SOL (${balance} lamports)`);
    
    // Создаем простой WalletManager
    const walletManager = {
      connection: connection,
      wallets: new Map([['phantom-wallet', keypair]]),
      walletInfo: new Map([['phantom-wallet', {
        publicKey: keypair.publicKey.toString(),
        balance: solBalance,
        tokenAccounts: new Map(),
        lastUpdated: Date.now(),
        nonce: 0,
        isActive: true
      }]]),
      
      getPrimaryWallet() {
        return this.wallets.get('phantom-wallet');
      },
      
      getWalletBalance(name) {
        const info = this.walletInfo.get(name);
        return info ? info.balance : 0;
      },
      
      async updateBalance(name) {
        const keypair = this.wallets.get(name);
        if (!keypair) return;
        
        try {
          const balance = await this.connection.getBalance(keypair.publicKey, 'confirmed');
          const solBalance = balance / 1e9;
          
          const info = this.walletInfo.get(name);
          if (info) {
            info.balance = solBalance;
            info.lastUpdated = Date.now();
          }
          
          console.log(`✅ Баланс обновлен: ${solBalance} SOL`);
        } catch (error) {
          console.error('❌ Ошибка обновления баланса:', error.message);
        }
      }
    };
    
    console.log('✅ WalletManager создан');
    
    // Тестируем методы
    const primaryWallet = walletManager.getPrimaryWallet();
    console.log('✅ Primary wallet:', primaryWallet ? primaryWallet.publicKey.toString() : 'null');
    
    const walletBalance = walletManager.getWalletBalance('phantom-wallet');
    console.log(`✅ Баланс из WalletManager: ${walletBalance} SOL`);
    
    // Обновляем баланс
    await walletManager.updateBalance('phantom-wallet');
    
    const updatedBalance = walletManager.getWalletBalance('phantom-wallet');
    console.log(`✅ Обновленный баланс: ${updatedBalance} SOL`);
    
  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

testFixedWallet().then(() => {
  console.log('🏁 ТЕСТ ЗАВЕРШЕН');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
