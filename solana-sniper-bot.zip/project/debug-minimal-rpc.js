#!/usr/bin/env node

import { Connection } from '@solana/web3.js';

console.log('🔧 Testing minimal RPCManager...');

async function testMinimalRPC() {
  try {
    console.log('🔧 Creating connections...');
    
    const endpoints = [
      'https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4',
      'https://vivianne-2tu8xb-fast-mainnet.helius-rpc.com'
    ];
    
    const connections = new Map();
    
    for (let i = 0; i < endpoints.length; i++) {
      const endpoint = endpoints[i];
      console.log(`🔗 Creating connection ${i + 1}...`);
      
      try {
        const connection = new Connection(endpoint, {
          commitment: 'processed',
          confirmTransactionInitialTimeout: 5000
        });
        
        connections.set(endpoint, connection);
        console.log(`✅ Connection ${i + 1} created`);
      } catch (error) {
        console.error(`❌ Connection ${i + 1} failed:`, error);
      }
    }
    
    console.log('✅ All connections created');
    
    // Test getting a connection
    const firstConnection = connections.values().next().value;
    if (firstConnection) {
      console.log('✅ First connection obtained');
      
      // Test a simple RPC call
      console.log('🔧 Testing RPC call...');
      const slot = await firstConnection.getSlot();
      console.log(`✅ RPC call successful, slot: ${slot}`);
    }
    
    console.log('✅ Test completed successfully!');
  } catch (error) {
    console.error('❌ Test failed:', error);
    process.exit(1);
  }
}

testMinimalRPC();
