#!/usr/bin/env node

console.log('🔍 АНАЛИЗ RPC ОШИБОК...');

async function analyzeRpcErrors() {
  try {
    const { Connection, PublicKey } = await import('@solana/web3.js');
    
    // Создаем соединение с Helius
    const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4', 'confirmed');
    console.log('✅ RPC соединение создано');
    
    // Тестируем несколько токенов из логов
    const testTokens = [
      'DBuoCQmCkvARi8TGoW4S8JcthT7Rgygb38ixCSsHcXHv',
      '6iQxBFbKwBmbxBpHQ5hL8je92fwH7RExq2Pw6DpNkuG5',
      '8SYy4YT2JHYJKVXz2UHmofyG6uLbbXPLRBJ3fWX1RcBu',
      'Ab64PgPkLJWfMZk9mbYvzEMtbhHziwMz3ELTEsLLm6Fc',
      'DzbTFXuiNgxDMtUuvVzzhfCbEktECK3DMp6mDGQP2fct'
    ];
    
    console.log('\n📊 ТЕСТИРОВАНИЕ RPC МЕТОДОВ:');
    
    for (const tokenMint of testTokens) {
      console.log(`\n🔍 Тестируем токен: ${tokenMint}`);
      
      try {
        // 1. Тест getAccountInfo
        console.log('  📋 Тест getAccountInfo...');
        const accountInfo = await connection.getAccountInfo(new PublicKey(tokenMint));
        if (accountInfo) {
          console.log(`  ✅ Account info получен: ${accountInfo.data.length} bytes`);
        } else {
          console.log('  ❌ Account info не найден');
        }
      } catch (error) {
        console.log(`  ❌ getAccountInfo ошибка: ${error.message}`);
      }
      
      try {
        // 2. Тест getTokenSupply
        console.log('  📊 Тест getTokenSupply...');
        const tokenSupply = await connection.getTokenSupply(new PublicKey(tokenMint));
        console.log(`  ✅ Token supply: ${tokenSupply.value.uiAmountString}`);
      } catch (error) {
        console.log(`  ❌ getTokenSupply ошибка: ${error.message}`);
      }
      
      try {
        // 3. Тест getTokenLargestAccounts
        console.log('  👥 Тест getTokenLargestAccounts...');
        const largestAccounts = await connection.getTokenLargestAccounts(new PublicKey(tokenMint));
        console.log(`  ✅ Largest accounts: ${largestAccounts.value.length} holders`);
      } catch (error) {
        console.log(`  ❌ getTokenLargestAccounts ошибка: ${error.message}`);
      }
      
      // Небольшая пауза между запросами
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    console.log('\n📊 АНАЛИЗ ЗАВЕРШЕН');
    
  } catch (error) {
    console.error('❌ КРИТИЧЕСКАЯ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
  }
}

analyzeRpcErrors().then(() => {
  console.log('🏁 АНАЛИЗ RPC ОШИБОК ЗАВЕРШЕН');
  process.exit(0);
}).catch((error) => {
  console.error('💥 ОШИБКА АНАЛИЗА:', error);
  process.exit(1);
});
