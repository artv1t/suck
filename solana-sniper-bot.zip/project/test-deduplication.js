#!/usr/bin/env node

/**
 * ISOLATED DeduplicationFilter Test
 */

console.log('🧪 Testing DeduplicationFilter...');

async function testDeduplicationFilter() {
  try {
    console.log('🔧 Importing DeduplicationFilter...');
    const { DeduplicationFilter } = await import('./dist/filters/deduplicationFilter.js');
    console.log('✅ DeduplicationFilter imported');

    console.log('🔧 Creating DeduplicationFilter...');
    const filter = new DeduplicationFilter();
    console.log('✅ DeduplicationFilter created');

    console.log('🔧 Testing with duplicate token...');
    const mintAddress = 'So11111111111111111111111111111111111111112';

    const result1 = await filter.execute(mintAddress);
    console.log('✅ First token result:', result1);

    const result2 = await filter.execute(mintAddress);
    console.log('✅ Duplicate token result:', result2);

    console.log('🔧 Testing getStats...');
    const stats = filter.getStats();
    console.log('✅ Stats:', stats);

    console.log('✅ DeduplicationFilter test completed!');

  } catch (error) {
    console.error('❌ DeduplicationFilter test failed:', error);
    process.exit(1);
  }
}

testDeduplicationFilter().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
