#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { Keypair } from '@solana/web3.js';

console.log('🔧 Testing loadWallets() function...');

// Simulate the loadWallets function
function loadWallets() {
  console.log('🔧 WalletManager: Starting wallet loading process...');
  
  try {
    // Load only phantom-wallet (main trading wallet)
    console.log('🔧 WalletManager: Loading phantom-wallet...');
    const phantomWalletPath = path.join('./wallets', 'phantom-wallet.json');
    
    if (fs.existsSync(phantomWalletPath)) {
      console.log(`🔧 WalletManager: Phantom wallet found: ${phantomWalletPath}`);
      const phantomWallet = loadWalletFromFile(phantomWalletPath, 'phantom-wallet');
      if (phantomWallet) {
        console.log(`✅ WalletManager: Phantom wallet loaded: ${phantomWallet.publicKey.toString()}`);
      } else {
        console.error(`❌ WalletManager: Failed to load phantom wallet from ${phantomWalletPath}`);
        throw new Error('Phantom wallet loading failed');
      }
    } else {
      console.error(`❌ WalletManager: Phantom wallet not found at ${phantomWalletPath}`);
      throw new Error('Phantom wallet not found');
    }
    
    console.log('✅ WalletManager: Wallet loading process completed');
  } catch (error) {
    console.error('❌ WalletManager: Failed to load wallets:', error);
    throw new Error('Wallet loading failed');
  }
}

// Simulate the loadWalletFromFile function
function loadWalletFromFile(filePath, name) {
  try {
    console.log(`🔧 WalletManager: Loading wallet from file: ${filePath}`);
    
    // Check file permissions
    const stats = fs.statSync(filePath);
    console.log(`🔧 WalletManager: File stats: mode=${stats.mode.toString(8)}`);
    
    if ((stats.mode & 0o077) !== 0) {
      console.log(`⚠️ Wallet file ${filePath} has insecure permissions, fixing...`);
      fs.chmodSync(filePath, 0o600); // Owner read/write only
    }

    const data = fs.readFileSync(filePath, 'utf8');
    console.log(`🔧 WalletManager: File data length: ${data.length}`);
    
    let keyData;
    try {
      const parsed = JSON.parse(data);
      console.log(`🔧 WalletManager: Parsed JSON keys: ${Object.keys(parsed)}`);
      
      // Handle different wallet file formats
      if (Array.isArray(parsed)) {
        keyData = parsed;
        console.log(`🔧 WalletManager: Using array format, length: ${keyData.length}`);
      } else if (parsed.privateKey) {
        keyData = parsed.privateKey;
        console.log(`🔧 WalletManager: Using privateKey format, length: ${keyData.length}`);
      } else if (parsed.secretKey) {
        keyData = parsed.secretKey;
        console.log(`🔧 WalletManager: Using secretKey format, length: ${keyData.length}`);
      } else {
        throw new Error('Invalid wallet file format');
      }
    } catch (parseError) {
      console.error(`❌ WalletManager: JSON parse error:`, parseError);
      throw parseError;
    }

    console.log(`🔧 WalletManager: Creating Keypair from ${keyData.length} bytes...`);
    const keypair = Keypair.fromSecretKey(new Uint8Array(keyData));
    console.log(`✅ WalletManager: Keypair created: ${keypair.publicKey.toString()}`);
    
    return keypair;
  } catch (error) {
    console.error(`❌ Failed to load wallet ${name}:`, error);
    return null;
  }
}

// Test the function
try {
  loadWallets();
  console.log('✅ Test completed successfully!');
} catch (error) {
  console.error('❌ Test failed:', error);
  process.exit(1);
}
