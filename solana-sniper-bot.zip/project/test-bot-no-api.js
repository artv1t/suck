#!/usr/bin/env node

console.log('🚀 ЗАПУСК БОТА ДЛЯ ТЕСТИРОВАНИЯ (БЕЗ API)...');

async function testBot() {
  try {
    const { BotManager } = await import('./dist/core/botManager.js');
    
    console.log('✅ Импорт BotManager успешен');
    
    // Создаем BotManager
    const botManager = new BotManager();
    console.log('✅ BotManager создан');
    
    // Инициализируем бота
    await botManager.initialize();
    console.log('✅ Бот инициализирован');
    
    // Запускаем бота
    await botManager.start();
    console.log('✅ Бот запущен');
    
    // Мониторим работу 60 секунд
    console.log('⏳ Мониторинг работы бота в течение 60 секунд...');
    
    let tokenCount = 0;
    let filterStats = {};
    
    // Слушаем события
    botManager.eventBus.on('tokenDetected', (token) => {
      tokenCount++;
      console.log(`🔍 Токен ${tokenCount} обнаружен: ${token.mint}`);
    });
    
    botManager.eventBus.on('filterResult', (result) => {
      const filterName = result.filterName;
      if (!filterStats[filterName]) {
        filterStats[filterName] = { passed: 0, failed: 0 };
      }
      
      if (result.ok) {
        filterStats[filterName].passed++;
        console.log(`✅ ${filterName}: ПРОШЕЛ (${result.score})`);
      } else {
        filterStats[filterName].failed++;
        console.log(`❌ ${filterName}: ОТКЛОНЕН (${result.reason})`);
      }
    });
    
    botManager.eventBus.on('tradeExecuted', (trade) => {
      console.log(`💰 ТОРГОВЛЯ: ${trade.side} ${trade.amount} ${trade.token}`);
    });
    
    // Ждем 60 секунд
    await new Promise(resolve => setTimeout(resolve, 60000));
    
    // Останавливаем бота
    await botManager.stop();
    console.log('✅ Бот остановлен');
    
    // Выводим статистику
    console.log('\n📊 СТАТИСТИКА ТЕСТИРОВАНИЯ:');
    console.log(`🔍 Всего токенов обнаружено: ${tokenCount}`);
    console.log('\n📈 СТАТИСТИКА ФИЛЬТРОВ:');
    for (const [filterName, stats] of Object.entries(filterStats)) {
      const total = stats.passed + stats.failed;
      const passRate = total > 0 ? (stats.passed / total * 100).toFixed(1) : 0;
      console.log(`  ${filterName}: ${stats.passed}/${total} (${passRate}%)`);
    }
    
    // Выводим метрики
    const metrics = botManager.getMetrics();
    console.log('\n📊 МЕТРИКИ БОТА:');
    console.log(`  RPC запросов: ${metrics.rpcRequests}`);
    console.log(`  Токенов обработано: ${metrics.tokensProcessed}`);
    console.log(`  Фильтров выполнено: ${metrics.filtersExecuted}`);
    console.log(`  Торговых операций: ${metrics.tradesExecuted}`);
    
  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

testBot().then(() => {
  console.log('🏁 ТЕСТИРОВАНИЕ ЗАВЕРШЕНО');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
