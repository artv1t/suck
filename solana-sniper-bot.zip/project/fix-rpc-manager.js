#!/usr/bin/env node

import fs from 'fs';
import path from 'path';

console.log('🔧 ИСПРАВЛЕНИЕ RPC MANAGER...');

const filePath = './src/rpc/rpcManager.ts';
const content = fs.readFileSync(filePath, 'utf8');

console.log('📖 Читаем файл...');

// Удаляем WebSocket код
const fixedContent = content
  .replace(/        console\.log\(`🔧 RPCManager: Getting WebSocket endpoint for connection \$\{index \+ 1\}\.\.\.`\);\n        const wsEndpoint = this\.getWebSocketEndpoint\(endpoint\);\n        console\.log\(`✅ RPCManager: WebSocket endpoint obtained for connection \$\{index \+ 1\}`\);\n        \n/g, '')
  .replace(/          wsEndpoint: wsEndpoint,\n/g, '');

console.log('✏️ Исправляем код...');

fs.writeFileSync(filePath, fixedContent);

console.log('✅ Файл исправлен!');

// Проверяем результат
const newContent = fs.readFileSync(filePath, 'utf8');
const wsCount = (newContent.match(/wsEndpoint/g) || []).length;

console.log(`📊 Количество wsEndpoint в файле: ${wsCount}`);

if (wsCount === 0) {
  console.log('✅ WebSocket код полностью удален!');
} else {
  console.log('❌ WebSocket код все еще есть!');
}
