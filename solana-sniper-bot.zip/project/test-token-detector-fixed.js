#!/usr/bin/env node

console.log('🔍 ТЕСТИРОВАНИЕ TOKENDETECTOR С ИСПРАВЛЕНИЯМИ...');

async function testTokenDetectorFixed() {
  try {
    const { RPCManager } = await import('./dist/rpc/rpcManager.js');
    const { TokenDetector } = await import('./dist/detector/tokenDetector.js');
    
    console.log('✅ Модули импортированы');
    
    // Создаем RPCManager
    const rpcManager = new RPCManager();
    console.log('✅ RPCManager создан');
    
    // Создаем TokenDetector
    const tokenDetector = new TokenDetector(rpcManager);
    console.log('✅ TokenDetector создан');
    
    // Запускаем TokenDetector
    await tokenDetector.start();
    console.log('✅ TokenDetector запущен');
    
    // Мониторим работу 30 секунд
    console.log('⏳ Мониторинг работы TokenDetector в течение 30 секунд...');
    
    let tokenCount = 0;
    let validTokenCount = 0;
    let invalidTokenCount = 0;
    
    // Слушаем события
    const eventBus = (await import('./dist/core/eventBus.js')).EventBus.getInstance();
    
    eventBus.on('tokenDetected', (token) => {
      tokenCount++;
      console.log(`🔍 Токен ${tokenCount} обнаружен: ${token.mintAddress} (источник: ${token.source})`);
    });
    
    // Ждем 30 секунд
    await new Promise(resolve => setTimeout(resolve, 30000));
    
    // Останавливаем TokenDetector
    await tokenDetector.stop();
    console.log('✅ TokenDetector остановлен');
    
    // Выводим статистику
    console.log('\n📊 СТАТИСТИКА TOKENDETECTOR:');
    console.log(`🔍 Всего токенов обнаружено: ${tokenCount}`);
    console.log(`✅ Валидных токенов: ${validTokenCount}`);
    console.log(`❌ Невалидных токенов: ${invalidTokenCount}`);
    
    // Выводим метрики очереди
    const queueMetrics = tokenDetector.getQueueMetrics();
    console.log(`📊 Размер очереди: ${queueMetrics.queueSize}`);
    console.log(`📊 Обработано событий: ${queueMetrics.processedEvents}`);
    
    console.log('\n✅ ТЕСТИРОВАНИЕ TOKENDETECTOR ЗАВЕРШЕНО');
    
  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

testTokenDetectorFixed().then(() => {
  console.log('🏁 ТЕСТИРОВАНИЕ ЗАВЕРШЕНО');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
