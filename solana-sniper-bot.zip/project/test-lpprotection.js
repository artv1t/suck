#!/usr/bin/env node

console.log('🧪 Testing LPProtectionFilter...');

async function testLPProtectionFilter() {
  try {
    const { LPProtectionFilter } = await import('./dist/filters/lpProtectionFilter.js');
    console.log('✅ LPProtectionFilter imported');

    const filter = new LPProtectionFilter();
    console.log('✅ LPProtectionFilter created');

    const testToken = {
      mint: 'So11111111111111111111111111111111111111112',
      symbol: 'SOL',
      name: 'Solana',
      decimals: 9,
      supply: 1000000000,
      verified: true
    };

    console.log('🔧 Testing execute() method...');
    const result = await filter.execute(testToken);
    console.log('✅ Result:', result);

    console.log('🔧 Testing getMetrics() method...');
    const metrics = filter.getMetrics();
    console.log('✅ Metrics:', metrics);

  } catch (error) {
    console.log('❌ Error:', error.message);
    process.exit(1);
  }
}

testLPProtectionFilter().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
