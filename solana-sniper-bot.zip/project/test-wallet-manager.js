#!/usr/bin/env node

console.log('🔍 ТЕСТ WALLET MANAGER...');

async function testWalletManager() {
  try {
    const { Connection, PublicKey } = await import('@solana/web3.js');
    const { WalletManager } = await import('./dist/wallet/walletManager.js');
    
    // Создаем прямое соединение с Helius
    const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4', 'confirmed');
    
    console.log('✅ Прямое соединение создано');
    console.log('🔗 RPC Endpoint:', connection.rpcEndpoint);
    
    // Создаем WalletManager
    const walletManager = new WalletManager(connection);
    console.log('✅ WalletManager создан');
    
    // Проверяем кошелек
    const primaryWallet = walletManager.getPrimaryWallet();
    if (!primaryWallet) {
      console.log('❌ Primary wallet не найден!');
      return;
    }

    console.log('✅ Primary wallet найден:', primaryWallet.publicKey.toString());
    
    // Тестируем прямое получение баланса
    console.log('💰 Тестирование прямого getBalance...');
    try {
      const balance = await connection.getBalance(primaryWallet.publicKey, 'confirmed');
      const solBalance = balance / 1e9;
      console.log(`✅ Прямой getBalance: ${solBalance} SOL (${balance} lamports)`);
    } catch (error) {
      console.log(`❌ Прямой getBalance failed: ${error.message}`);
    }
    
    // Тестируем через WalletManager
    console.log('💰 Тестирование через WalletManager...');
    try {
      const walletBalance = walletManager.getWalletBalance('phantom-wallet');
      console.log(`✅ WalletManager баланс: ${walletBalance} SOL`);
    } catch (error) {
      console.log(`❌ WalletManager баланс failed: ${error.message}`);
    }
    
    // Принудительно обновляем баланс
    console.log('💰 Принудительное обновление баланса...');
    try {
      // Вызываем приватный метод через рефлексию
      const updateMethod = walletManager.updateWalletBalance;
      if (typeof updateMethod === 'function') {
        await updateMethod.call(walletManager, 'phantom-wallet');
        console.log('✅ Баланс обновлен');
        
        const updatedBalance = walletManager.getWalletBalance('phantom-wallet');
        console.log(`✅ Обновленный баланс: ${updatedBalance} SOL`);
      } else {
        console.log('❌ Метод updateWalletBalance не найден');
      }
    } catch (error) {
      console.log(`❌ Принудительное обновление failed: ${error.message}`);
    }
    
  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

testWalletManager().then(() => {
  console.log('🏁 ТЕСТ ЗАВЕРШЕН');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
