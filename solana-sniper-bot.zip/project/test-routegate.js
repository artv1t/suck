#!/usr/bin/env node

console.log('🧪 Testing RouteGateFilter...');

async function testRouteGateFilter() {
  try {
    const { RouteGateFilter } = await import('./dist/filters/routeGateFilter.js');
    console.log('✅ RouteGateFilter imported');

    const filter = new RouteGateFilter();
    console.log('✅ RouteGateFilter created');

    const mintAddress = 'So11111111111111111111111111111111111111112';
    const result = await filter.execute(mintAddress);
    console.log('✅ Token result:', result);

    const metrics = filter.getMetrics();
    console.log('✅ Metrics:', metrics);

    console.log('✅ RouteGateFilter test completed!');

  } catch (error) {
    console.error('❌ RouteGateFilter test failed:', error);
    process.exit(1);
  }
}

testRouteGateFilter().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
