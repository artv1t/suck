#!/usr/bin/env node

import { BotManager } from './dist/core/botManager.js';

console.log('🔧 Testing BotManager initialization...');

async function testBotManager() {
  try {
    console.log('🔧 Creating BotManager...');
    const botManager = new BotManager();
    console.log('✅ BotManager created successfully');
    
    console.log('🔧 Initializing BotManager...');
    await botManager.initialize();
    console.log('✅ BotManager initialized successfully');
    
    console.log('🔧 Starting BotManager...');
    await botManager.start();
    console.log('✅ BotManager started successfully');
    
    // Wait a bit to see if it runs
    console.log('🔧 Waiting 5 seconds...');
    await new Promise(resolve => setTimeout(resolve, 5000));
    
    console.log('🔧 Stopping BotManager...');
    await botManager.stop();
    console.log('✅ BotManager stopped successfully');
    
    console.log('✅ Test completed successfully!');
  } catch (error) {
    console.error('❌ Test failed:', error);
    console.error('Error details:', {
      message: error.message,
      stack: error.stack,
      name: error.name
    });
    process.exit(1);
  }
}

testBotManager();
