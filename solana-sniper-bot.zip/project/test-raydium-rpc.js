#!/usr/bin/env node

console.log('🧪 Testing RaydiumService findRaydiumPoolsViaRPC method...');

async function testRaydiumRPC() {
  try {
    const { raydiumService } = await import('./dist/services/raydiumService.js');
    console.log('✅ RaydiumService imported');

    const mintAddress = 'So11111111111111111111111111111111111111112';
    
    console.log('🔧 Testing findRaydiumPoolsViaRPC with timeout...');
    const startTime = Date.now();
    
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('RPC test timeout after 4 seconds')), 4000);
    });
    
    // Access private method via reflection (hack for testing)
    const rpcMethod = raydiumService.findRaydiumPoolsViaRPC || raydiumService.constructor.prototype.findRaydiumPoolsViaRPC;
    
    if (!rpcMethod) {
      console.log('❌ Cannot access findRaydiumPoolsViaRPC method');
      return;
    }
    
    const result = await Promise.race([rpcMethod.call(raydiumService, mintAddress), timeoutPromise]);
    
    const endTime = Date.now();
    console.log('✅ RPC result:', result);
    console.log('✅ Time taken:', endTime - startTime, 'ms');

  } catch (error) {
    console.log('❌ RPC error:', error.message);
    if (error.message.includes('timeout')) {
      console.log('❌ RaydiumService findRaydiumPoolsViaRPC is timing out!');
    }
    process.exit(1);
  }
}

testRaydiumRPC().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
