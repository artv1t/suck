#!/usr/bin/env node

/**
 * ISOLATED WalletManager Test
 * Tests WalletManager initialization without other components
 */

console.log('🧪 Starting isolated WalletManager test...');
console.log('🧪 This will help identify if WalletManager is causing the hang');

async function testWalletManager() {
  try {
    console.log('🔧 Importing RPCManager...');
    const { RPCManager } = await import('./src/rpc/rpcManager.js');
    console.log('✅ RPCManager imported successfully');

    console.log('🔧 Creating RPCManager instance...');
    const rpcManager = new RPCManager();
    console.log('✅ RPCManager instance created successfully');

    console.log('🔧 Getting healthy connection...');
    const connection = rpcManager.getHealthyConnection();
    if (!connection) {
      throw new Error('No healthy RPC connection available');
    }
    console.log('✅ Healthy connection obtained');

    console.log('🔧 Importing WalletManager...');
    const { WalletManager } = await import('./src/wallet/walletManager.js');
    console.log('✅ WalletManager imported successfully');

    console.log('🔧 Creating WalletManager instance...');
    const walletManager = new WalletManager(connection);
    console.log('✅ WalletManager instance created successfully');

    console.log('🔧 Testing getPrimaryWallet...');
    const primaryWallet = walletManager.getPrimaryWallet();
    console.log('✅ Primary wallet:', primaryWallet ? 'FOUND' : 'NOT FOUND');

    console.log('🔧 Testing getAllWalletInfo...');
    const allWallets = walletManager.getAllWalletInfo();
    console.log('✅ All wallets count:', allWallets.size);

    console.log('🔧 Testing getMetrics...');
    const metrics = walletManager.getMetrics();
    console.log('✅ Wallet metrics:', metrics);

    console.log('🔧 Waiting 10 seconds to test balance monitoring...');
    await new Promise(resolve => setTimeout(resolve, 10000));
    console.log('✅ Balance monitoring test completed');

    console.log('✅ WalletManager test completed successfully!');
    console.log('🎯 WalletManager is NOT causing the hang');

  } catch (error) {
    console.error('❌ WalletManager test failed:', error);
    console.log('🎯 WalletManager IS causing the hang');
    process.exit(1);
  }
}

// Run the test
testWalletManager().then(() => {
  console.log('🏁 Test completed, exiting...');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});