#!/usr/bin/env node

console.log('🔍 ТЕСТ ПРИНУДИТЕЛЬНОГО ОБНОВЛЕНИЯ...');

async function testForceUpdate() {
  try {
    const { RPCManager } = await import('./dist/rpc/rpcManager.js');
    const { WalletManager } = await import('./dist/wallet/walletManager.js');
    
    // Создаем RPC Manager
    const rpcManager = new RPCManager();
    console.log('✅ RPC Manager создан');

    // Получаем здоровое соединение
    const connection = rpcManager.getHealthyConnection();
    if (!connection) {
      console.log('❌ Нет здорового соединения!');
      return;
    }
    
    console.log('✅ Здоровое соединение получено');
    console.log('🔗 RPC Endpoint:', connection.rpcEndpoint);

    // Создаем Wallet Manager
    const walletManager = new WalletManager(connection);
    console.log('✅ Wallet Manager создан');

    // Ждем 2 секунды для завершения инициализации
    console.log('⏳ Ждем завершения инициализации...');
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Проверяем кошелек
    const primaryWallet = walletManager.getPrimaryWallet();
    if (!primaryWallet) {
      console.log('❌ Primary wallet не найден!');
      return;
    }

    console.log('✅ Primary wallet найден:', primaryWallet.publicKey.toString());

    // Проверяем баланс
    const balance = walletManager.getWalletBalance('phantom-wallet');
    console.log(`💰 Текущий баланс: ${balance} SOL`);

    // Принудительно обновляем баланс
    console.log('🔄 Принудительное обновление баланса...');
    try {
      // Вызываем приватный метод через рефлексию
      const updateMethod = walletManager.updateWalletBalance;
      if (typeof updateMethod === 'function') {
        await updateMethod.call(walletManager, 'phantom-wallet');
        console.log('✅ Баланс обновлен');
        
        const updatedBalance = walletManager.getWalletBalance('phantom-wallet');
        console.log(`💰 Обновленный баланс: ${updatedBalance} SOL`);
      } else {
        console.log('❌ Метод updateWalletBalance не найден');
      }
    } catch (error) {
      console.log(`❌ Принудительное обновление failed: ${error.message}`);
    }

  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

testForceUpdate().then(() => {
  console.log('🏁 ТЕСТ ЗАВЕРШЕН');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
