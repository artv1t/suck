#!/usr/bin/env node

console.log('🔍 ТЕСТИРОВАНИЕ TOKENDETECTOR ЧЕРЕЗ BOTMANAGER...');

async function testBotTokenDetector() {
  try {
    const { BotManager } = await import('./dist/core/botManager.js');
    
    console.log('✅ BotManager импортирован');
    
    // Создаем BotManager
    const botManager = new BotManager();
    console.log('✅ BotManager создан');
    
    // Инициализируем бота
    await botManager.initialize();
    console.log('✅ Бот инициализирован');
    
    // Запускаем бота
    await botManager.start();
    console.log('✅ Бот запущен');
    
    // Мониторим работу 30 секунд
    console.log('⏳ Мониторинг работы TokenDetector в течение 30 секунд...');
    
    let tokenCount = 0;
    let filterResults = {};
    
    // Слушаем события через EventBus
    const { EventBus } = await import('./dist/core/eventBus.js');
    const eventBus = EventBus.getInstance();
    
    eventBus.on('tokenDetected', (token) => {
      tokenCount++;
      console.log(`🔍 Токен ${tokenCount} обнаружен: ${token.mintAddress} (источник: ${token.source})`);
    });
    
    eventBus.on('filterResult', (result) => {
      const filterName = result.filterName;
      if (!filterResults[filterName]) {
        filterResults[filterName] = { passed: 0, failed: 0 };
      }
      
      if (result.ok) {
        filterResults[filterName].passed++;
        console.log(`✅ ${filterName}: ПРОШЕЛ (${result.score})`);
      } else {
        filterResults[filterName].failed++;
        console.log(`❌ ${filterName}: ОТКЛОНЕН (${result.reason})`);
      }
    });
    
    // Ждем 30 секунд
    await new Promise(resolve => setTimeout(resolve, 30000));
    
    // Останавливаем бота
    await botManager.stop();
    console.log('✅ Бот остановлен');
    
    // Выводим статистику
    console.log('\n📊 СТАТИСТИКА TOKENDETECTOR:');
    console.log(`🔍 Всего токенов обнаружено: ${tokenCount}`);
    
    console.log('\n📈 СТАТИСТИКА ФИЛЬТРОВ:');
    for (const [filterName, stats] of Object.entries(filterResults)) {
      const total = stats.passed + stats.failed;
      const passRate = total > 0 ? (stats.passed / total * 100).toFixed(1) : 0;
      console.log(`  ${filterName}: ${stats.passed}/${total} (${passRate}%)`);
    }
    
    // Выводим метрики
    const metrics = botManager.getMetrics();
    console.log('\n📊 МЕТРИКИ БОТА:');
    console.log(`  RPC запросов: ${metrics.rpcRequests}`);
    console.log(`  Токенов обработано: ${metrics.tokensProcessed}`);
    console.log(`  Фильтров выполнено: ${metrics.filtersExecuted}`);
    console.log(`  Торговых операций: ${metrics.tradesExecuted}`);
    
    console.log('\n✅ ТЕСТИРОВАНИЕ TOKENDETECTOR ЗАВЕРШЕНО');
    
  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

testBotTokenDetector().then(() => {
  console.log('🏁 ТЕСТИРОВАНИЕ ЗАВЕРШЕНО');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
