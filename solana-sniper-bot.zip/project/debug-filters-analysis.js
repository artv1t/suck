#!/usr/bin/env node

console.log('🔍 АНАЛИЗ РАБОТЫ ФИЛЬТРОВ...');

async function analyzeFilters() {
  try {
    const { Connection } = await import('@solana/web3.js');
    
    // Создаем соединение с Helius
    const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4', 'confirmed');
    console.log('✅ RPC соединение создано');
    
    // Импортируем модули
    const { RPCManager } = await import('./dist/rpc/rpcManager.js');
    const { FilterPipeline } = await import('./dist/filters/filterPipeline.js');
    const { OnChainFilter } = await import('./dist/filters/onChainFilter.js');
    const { RouteGateFilter } = await import('./dist/filters/routeGateFilter.js');
    
    console.log('✅ Модули импортированы');
    
    // Создаем RPCManager
    const rpcManager = new RPCManager();
    console.log('✅ RPCManager создан');
    
    // Создаем FilterPipeline
    const filterPipeline = new FilterPipeline(rpcManager);
    console.log('✅ FilterPipeline создан');
    
    // Тестируем с реальными токенами
    const testTokens = [
      {
        mint: 'So11111111111111111111111111111111111111112', // Wrapped SOL
        name: 'Wrapped SOL',
        symbol: 'WSOL'
      },
      {
        mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v', // USDC
        name: 'USD Coin',
        symbol: 'USDC'
      },
      {
        mint: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB', // USDT
        name: 'Tether USD',
        symbol: 'USDT'
      }
    ];
    
    console.log('\n📊 ТЕСТИРОВАНИЕ ФИЛЬТРОВ:');
    
    for (const token of testTokens) {
      console.log(`\n🔍 Тестируем токен: ${token.name} (${token.symbol})`);
      console.log(`   Mint: ${token.mint}`);
      
      try {
        // Тестируем FilterPipeline
        console.log('  🔄 Тест FilterPipeline...');
        const pipelineResult = await filterPipeline.processToken(token);
        console.log(`  ✅ FilterPipeline результат: ${pipelineResult.ok ? 'ПРОШЕЛ' : 'ОТКЛОНЕН'}`);
        if (!pipelineResult.ok) {
          console.log(`  📋 Причина: ${pipelineResult.reason}`);
        }
        console.log(`  📊 Оценка: ${pipelineResult.score}`);
        
      } catch (error) {
        console.log(`  ❌ FilterPipeline ошибка: ${error.message}`);
      }
      
      // Небольшая пауза между тестами
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
    
    // Тестируем OnChainFilter отдельно
    console.log('\n🔧 ТЕСТИРОВАНИЕ ONCHAINFILTER:');
    try {
      const onChainFilter = new OnChainFilter(connection);
      console.log('  ✅ OnChainFilter создан');
      
      const testToken = testTokens[0]; // Wrapped SOL
      console.log(`  🔍 Тестируем OnChainFilter с ${testToken.name}...`);
      
      const onChainResult = await onChainFilter.execute(testToken);
      console.log(`  ✅ OnChainFilter результат: ${onChainResult.ok ? 'ПРОШЕЛ' : 'ОТКЛОНЕН'}`);
      if (!onChainResult.ok) {
        console.log(`  📋 Причина: ${onChainResult.reason}`);
      }
      console.log(`  📊 Оценка: ${onChainResult.score}`);
      
    } catch (error) {
      console.log(`  ❌ OnChainFilter ошибка: ${error.message}`);
    }
    
    // Тестируем RouteGateFilter отдельно
    console.log('\n🔧 ТЕСТИРОВАНИЕ ROUTEGATEFILTER:');
    try {
      const routeGateFilter = new RouteGateFilter(connection);
      console.log('  ✅ RouteGateFilter создан');
      
      const testToken = testTokens[0]; // Wrapped SOL
      console.log(`  🔍 Тестируем RouteGateFilter с ${testToken.name}...`);
      
      const routeGateResult = await routeGateFilter.execute(testToken);
      console.log(`  ✅ RouteGateFilter результат: ${routeGateResult.ok ? 'ПРОШЕЛ' : 'ОТКЛОНЕН'}`);
      if (!routeGateResult.ok) {
        console.log(`  📋 Причина: ${routeGateResult.reason}`);
      }
      console.log(`  📊 Оценка: ${routeGateResult.score}`);
      
    } catch (error) {
      console.log(`  ❌ RouteGateFilter ошибка: ${error.message}`);
    }
    
    console.log('\n📊 АНАЛИЗ ЗАВЕРШЕН');
    
  } catch (error) {
    console.error('❌ КРИТИЧЕСКАЯ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
  }
}

analyzeFilters().then(() => {
  console.log('🏁 АНАЛИЗ РАБОТЫ ФИЛЬТРОВ ЗАВЕРШЕН');
  process.exit(0);
}).catch((error) => {
  console.error('💥 ОШИБКА АНАЛИЗА:', error);
  process.exit(1);
});
