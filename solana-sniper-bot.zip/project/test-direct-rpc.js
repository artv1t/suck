#!/usr/bin/env node

console.log('🔍 ТЕСТ ПРЯМОГО RPC...');

async function testDirectRPC() {
  try {
    const { Connection, PublicKey } = await import('@solana/web3.js');
    
    // Создаем прямое соединение с Helius
    const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4', 'confirmed');
    
    console.log('✅ Прямое соединение создано');
    console.log('🔗 RPC Endpoint:', connection.rpcEndpoint);
    
    // Твой адрес кошелька
    const walletAddress = '66oVmpHN499TGxc2e5WY4pB1yEYqkZnwex5o88MSgiGr';
    const publicKey = new PublicKey(walletAddress);
    
    console.log('🔑 Адрес кошелька:', walletAddress);
    
    // Тестируем getBalance с timeout
    console.log('💰 Тестирование getBalance с timeout...');
    
    const balancePromise = connection.getBalance(publicKey, 'confirmed');
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('getBalance timeout after 5 seconds')), 5000);
    });
    
    try {
      const balance = await Promise.race([balancePromise, timeoutPromise]);
      const solBalance = balance / 1e9;
      console.log(`✅ Баланс получен: ${solBalance} SOL (${balance} lamports)`);
    } catch (error) {
      console.log(`❌ Ошибка getBalance: ${error.message}`);
    }
    
    // Тестируем getAccountInfo с timeout
    console.log('📊 Тестирование getAccountInfo с timeout...');
    
    const accountPromise = connection.getAccountInfo(publicKey);
    const accountTimeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('getAccountInfo timeout after 5 seconds')), 5000);
    });
    
    try {
      const accountInfo = await Promise.race([accountPromise, accountTimeoutPromise]);
      if (accountInfo) {
        console.log('✅ Аккаунт найден');
      } else {
        console.log('❌ Аккаунт не найден');
      }
    } catch (error) {
      console.log(`❌ Ошибка getAccountInfo: ${error.message}`);
    }
    
  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

testDirectRPC().then(() => {
  console.log('🏁 ТЕСТ ЗАВЕРШЕН');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
