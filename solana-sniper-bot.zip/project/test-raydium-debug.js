#!/usr/bin/env node

console.log('🧪 Testing RaydiumService directly...');

async function testRaydiumService() {
  try {
    const { raydiumService } = await import('./dist/services/raydiumService.js');
    console.log('✅ RaydiumService imported');

    const mintAddress = 'So11111111111111111111111111111111111111112';
    
    console.log('🔧 Testing checkLiquidity with timeout...');
    const startTime = Date.now();
    
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Raydium timeout after 5 seconds')), 5000);
    });
    
    const liquidityPromise = raydiumService.checkLiquidity(mintAddress);
    
    const result = await Promise.race([liquidityPromise, timeoutPromise]);
    
    const endTime = Date.now();
    console.log('✅ Raydium result:', result);
    console.log('✅ Time taken:', endTime - startTime, 'ms');

  } catch (error) {
    console.log('❌ Raydium error:', error.message);
    if (error.message.includes('timeout')) {
      console.log('❌ RaydiumService is also timing out!');
    }
    process.exit(1);
  }
}

testRaydiumService().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
