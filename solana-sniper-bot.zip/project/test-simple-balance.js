#!/usr/bin/env node

console.log('🔍 ПРОСТОЙ ТЕСТ БАЛАНСА...');

async function testSimpleBalance() {
  try {
    const { Connection, PublicKey } = await import('@solana/web3.js');
    
    // Создаем прямое соединение с Helius
    const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4', 'confirmed');
    
    console.log('✅ Прямое соединение создано');
    console.log('🔗 RPC Endpoint:', connection.rpcEndpoint);
    
    // Твой адрес кошелька
    const walletAddress = '66oVmpHN499TGxc2e5WY4pB1yEYqkZnwex5o88MSgiGr';
    const publicKey = new PublicKey(walletAddress);
    
    console.log('🔑 Адрес кошелька:', walletAddress);
    
    // Получаем баланс
    console.log('💰 Получение баланса...');
    const balance = await connection.getBalance(publicKey, 'confirmed');
    const solBalance = balance / 1e9;
    
    console.log(`✅ Баланс: ${solBalance} SOL (${balance} lamports)`);
    
    // Получаем информацию об аккаунте
    console.log('📊 Получение информации об аккаунте...');
    const accountInfo = await connection.getAccountInfo(publicKey);
    
    if (accountInfo) {
      console.log('✅ Аккаунт найден');
      console.log('📊 Owner:', accountInfo.owner.toString());
      console.log('📊 Executable:', accountInfo.executable);
      console.log('📊 Rent Epoch:', accountInfo.rentEpoch);
    } else {
      console.log('❌ Аккаунт не найден');
    }
    
  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

testSimpleBalance().then(() => {
  console.log('🏁 ТЕСТ ЗАВЕРШЕН');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
