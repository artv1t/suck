#!/usr/bin/env node

import fs from 'fs';
import path from 'path';

console.log('🔧 Testing ensureDirectories() function...');

// Simulate the ensureDirectories function
function ensureDirectories() {
  console.log('🔧 WalletManager: ensureDirectories() called');
  
  try {
    const WALLET_DIR = './wallets';
    const BACKUP_DIR = './wallets/backup';
    const dirs = [WALLET_DIR, BACKUP_DIR];
    console.log('🔧 WalletManager: Directories to ensure:', dirs);
    
    for (const dir of dirs) {
      console.log(`🔧 WalletManager: Checking directory: ${dir}`);
      
      try {
        if (!fs.existsSync(dir)) {
          console.log(`🔧 WalletManager: Creating directory: ${dir}`);
          fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); // Owner only
          console.log(`✅ WalletManager: Directory created: ${dir}`);
        } else {
          console.log(`🔧 WalletManager: Directory exists, checking permissions: ${dir}`);
          // Check if we can set permissions (skip if not possible)
          try {
            fs.chmodSync(dir, 0o700);
            console.log(`✅ WalletManager: Permissions set for: ${dir}`);
          } catch (chmodError) {
            console.log(`⚠️ WalletManager: Could not set permissions for ${dir}: ${chmodError instanceof Error ? chmodError.message : 'Unknown error'}`);
            console.log(`✅ WalletManager: Continuing without permission change for: ${dir}`);
          }
        }
      } catch (dirError) {
        console.error(`❌ WalletManager: Error processing directory ${dir}:`, dirError);
        throw new Error(`Failed to process directory ${dir}: ${dirError instanceof Error ? dirError.message : 'Unknown error'}`);
      }
    }
    
    console.log('✅ WalletManager: ensureDirectories() completed');
  } catch (error) {
    console.error('❌ WalletManager: ensureDirectories() failed:', error);
    throw new Error(`Directory setup failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}

// Test the function
try {
  ensureDirectories();
  console.log('✅ Test completed successfully!');
} catch (error) {
  console.error('❌ Test failed:', error);
  process.exit(1);
}
