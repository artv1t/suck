#!/usr/bin/env node

/**
 * ISOLATED RPCManager Test
 * Tests RPCManager initialization without other components
 */

console.log('🧪 Starting isolated RPCManager test...');
console.log('🧪 This will help identify if RPCManager is causing the hang');

async function testRPCManager() {
  try {
    console.log('🔧 Importing RPCManager...');
    const { RPCManager } = await import('./src/rpc/rpcManager.js');
    console.log('✅ RPCManager imported successfully');

    console.log('🔧 Creating RPCManager instance...');
    const rpcManager = new RPCManager();
    console.log('✅ RPCManager instance created successfully');

    console.log('🔧 Testing getHealthyConnection...');
    const connection = rpcManager.getHealthyConnection();
    console.log('✅ getHealthyConnection result:', connection ? 'SUCCESS' : 'NULL');

    if (connection) {
      console.log('🔧 Testing connection.getVersion()...');
      const version = await connection.getVersion();
      console.log('✅ Connection version:', version);
    }

    console.log('🔧 Testing getHealthStatus...');
    const healthStatus = rpcManager.getHealthStatus();
    console.log('✅ Health status:', healthStatus.length, 'endpoints');

    console.log('🔧 Testing getAverageLatency...');
    const avgLatency = rpcManager.getAverageLatency();
    console.log('✅ Average latency:', avgLatency, 'ms');

    console.log('✅ RPCManager test completed successfully!');
    console.log('🎯 RPCManager is NOT causing the hang');

  } catch (error) {
    console.error('❌ RPCManager test failed:', error);
    console.log('🎯 RPCManager IS causing the hang');
    process.exit(1);
  }
}

// Run the test
testRPCManager().then(() => {
  console.log('🏁 Test completed, exiting...');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});