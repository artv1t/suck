#!/usr/bin/env node

console.log('🧪 Testing RouteGateFilter with detailed debugging...');

async function testRouteGateFilterDebug() {
  try {
    const { RouteGateFilter } = await import('./dist/filters/routeGateFilter.js');
    console.log('✅ RouteGateFilter imported');

    const filter = new RouteGateFilter();
    console.log('✅ RouteGateFilter created');

    const mintAddress = 'So11111111111111111111111111111111111111112';
    
    console.log('🔧 Testing with detailed logging...');
    console.log('🔧 Starting execute() at:', new Date().toISOString());
    
    const startTime = Date.now();
    
    // Add multiple timeout layers
    const timeout1 = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Test timeout 1 after 3 seconds')), 3000);
    });
    
    const timeout2 = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Test timeout 2 after 5 seconds')), 5000);
    });
    
    const executePromise = filter.execute(mintAddress);
    
    console.log('🔧 Promise.race started at:', new Date().toISOString());
    
    const result = await Promise.race([executePromise, timeout1, timeout2]);
    
    const endTime = Date.now();
    console.log('✅ Result received at:', new Date().toISOString());
    console.log('✅ Total time:', endTime - startTime, 'ms');
    console.log('✅ Result:', result);

  } catch (error) {
    const endTime = Date.now();
    console.log('❌ Error at:', new Date().toISOString());
    console.log('❌ Error after:', endTime - Date.now(), 'ms');
    console.log('❌ Error:', error.message);
    
    if (error.message.includes('timeout')) {
      console.log('❌ RouteGateFilter STILL TIMING OUT!');
    }
    process.exit(1);
  }
}

testRouteGateFilterDebug().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
