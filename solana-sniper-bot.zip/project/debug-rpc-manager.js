#!/usr/bin/env node

import { Connection } from '@solana/web3.js';

console.log('🔧 Testing RPCManager initialization...');

// Simulate the RPCManager constructor
async function testRPCManager() {
  try {
    console.log('🔧 RPCManager: Starting initialization...');
    
    // Test endpoints from config
    const rpcEndpoints = [
      'https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4',
      'https://vivianne-2tu8xb-fast-mainnet.helius-rpc.com',
      'https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4',
      'https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4'
    ];
    
    console.log('🔧 RPCManager: About to initialize connections...');
    const connections = new Map();
    
    for (let i = 0; i < rpcEndpoints.length; i++) {
      const endpoint = rpcEndpoints[i];
      try {
        console.log(`🔗 RPCManager: Creating connection ${i + 1} to ${maskEndpoint(endpoint)}...`);
        
        console.log(`🔧 RPCManager: Creating Connection object for ${i + 1}...`);
        const connection = new Connection(endpoint, {
          commitment: 'processed',
          confirmTransactionInitialTimeout: 5000,
          httpHeaders: {
            'Connection': 'keep-alive',
            'Keep-Alive': 'timeout=30, max=1000'
          }
        });
        console.log(`✅ RPCManager: Connection ${i + 1} created successfully`);
        
        connections.set(endpoint, connection);
        console.log(`✅ RPC ${i + 1} initialized: ${maskEndpoint(endpoint)}`);
      } catch (error) {
        console.error(`❌ Failed to initialize RPC ${i + 1}: ${maskEndpoint(endpoint)}`, error);
      }
    }
    console.log('✅ RPCManager: All connections initialized');
    
    console.log('🔧 RPCManager: About to start health checks...');
    // Skip health checks for now
    console.log('✅ RPCManager: Health checks skipped for testing');
    
    console.log('🔧 RPCManager: About to start metrics collection...');
    // Skip metrics collection for now
    console.log('✅ RPCManager: Metrics collection skipped for testing');
    
    console.log('✅ RPCManager: Constructor completed');
    
    // Test getting a healthy connection
    console.log('🔧 RPCManager: Testing getHealthyConnection...');
    const healthyConnection = getHealthyConnection(connections);
    if (healthyConnection) {
      console.log('✅ RPCManager: Healthy connection obtained');
    } else {
      console.log('❌ RPCManager: No healthy connection available');
    }
    
    console.log('✅ Test completed successfully!');
  } catch (error) {
    console.error('❌ Test failed:', error);
    console.error('Error details:', {
      message: error.message,
      stack: error.stack,
      name: error.name
    });
    process.exit(1);
  }
}

function maskEndpoint(endpoint) {
  return endpoint.replace(/api-key=[\w-]+/gi, 'api-key=***')
                .replace(/\/v2\/[\w-]+/gi, '/v2/***');
}

function getHealthyConnection(connections) {
  // Simple implementation - just return the first connection
  const firstConnection = connections.values().next().value;
  return firstConnection || null;
}

testRPCManager();
