#!/usr/bin/env node

console.log('🔍 АНАЛИЗ ПРОБЛЕМЫ С БАЛАНСОМ...');

async function analyzeBalanceIssue() {
  try {
    const { Connection, PublicKey } = await import('@solana/web3.js');
    
    // Создаем соединение с Helius
    const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4', 'confirmed');
    console.log('✅ RPC соединение создано');
    
    // Публичный ключ кошелька
    const walletPublicKey = '66oVmpHN499TGxc2e5WY4pB1yEYqkZnwex5o88MSgiGr';
    console.log(`🔑 Тестируем кошелек: ${walletPublicKey}`);
    
    console.log('\n📊 ТЕСТИРОВАНИЕ ПОЛУЧЕНИЯ БАЛАНСА:');
    
    // 1. Прямой запрос баланса
    console.log('  💰 Прямой запрос getBalance...');
    try {
      const balance = await connection.getBalance(new PublicKey(walletPublicKey));
      console.log(`  ✅ Баланс получен: ${balance} lamports (${balance / 1e9} SOL)`);
    } catch (error) {
      console.log(`  ❌ getBalance ошибка: ${error.message}`);
    }
    
    // 2. Запрос с контекстом
    console.log('  📋 Запрос getBalanceAndContext...');
    try {
      const balanceContext = await connection.getBalanceAndContext(new PublicKey(walletPublicKey));
      console.log(`  ✅ Баланс с контекстом: ${balanceContext.value} lamports (${balanceContext.value / 1e9} SOL)`);
      console.log(`  📊 Slot: ${balanceContext.context.slot}`);
    } catch (error) {
      console.log(`  ❌ getBalanceAndContext ошибка: ${error.message}`);
    }
    
    // 3. Проверка аккаунта
    console.log('  🔍 Проверка getAccountInfo...');
    try {
      const accountInfo = await connection.getAccountInfo(new PublicKey(walletPublicKey));
      if (accountInfo) {
        console.log(`  ✅ Аккаунт найден: ${accountInfo.data.length} bytes, lamports: ${accountInfo.lamports}`);
        console.log(`  📊 Owner: ${accountInfo.owner.toString()}`);
        console.log(`  📊 Executable: ${accountInfo.executable}`);
      } else {
        console.log('  ❌ Аккаунт не найден');
      }
    } catch (error) {
      console.log(`  ❌ getAccountInfo ошибка: ${error.message}`);
    }
    
    // 4. Тест WalletManager
    console.log('\n🔧 ТЕСТИРОВАНИЕ WALLETMANAGER:');
    try {
      const { WalletManager } = await import('./dist/wallet/walletManager.js');
      const { RPCManager } = await import('./dist/rpc/rpcManager.js');
      
      console.log('  📦 Импорт модулей успешен');
      
      // Создаем RPCManager
      const rpcManager = new RPCManager();
      console.log('  ✅ RPCManager создан');
      
      // Создаем WalletManager
      const walletManager = new WalletManager(connection);
      console.log('  ✅ WalletManager создан');
      
      // Ждем немного для инициализации
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Проверяем баланс через WalletManager
      const walletBalance = walletManager.getWalletBalance('phantom-wallet');
      console.log(`  💰 Баланс через WalletManager: ${walletBalance} SOL`);
      
      // Проверяем primary wallet
      const primaryWallet = walletManager.getPrimaryWallet();
      if (primaryWallet) {
        console.log(`  🔑 Primary wallet: ${primaryWallet.publicKey.toString()}`);
      } else {
        console.log('  ❌ Primary wallet не найден');
      }
      
    } catch (error) {
      console.log(`  ❌ WalletManager ошибка: ${error.message}`);
      console.log(`  📋 Stack: ${error.stack}`);
    }
    
    console.log('\n📊 АНАЛИЗ ЗАВЕРШЕН');
    
  } catch (error) {
    console.error('❌ КРИТИЧЕСКАЯ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
  }
}

analyzeBalanceIssue().then(() => {
  console.log('🏁 АНАЛИЗ ПРОБЛЕМЫ С БАЛАНСОМ ЗАВЕРШЕН');
  process.exit(0);
}).catch((error) => {
  console.error('💥 ОШИБКА АНАЛИЗА:', error);
  process.exit(1);
});
