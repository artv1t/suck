#!/usr/bin/env node

console.log('🧪 Testing RouteGateFilter with timeout...');

async function testRouteGateFilterWithTimeout() {
  try {
    const { RouteGateFilter } = await import('./dist/filters/routeGateFilter.js');
    console.log('✅ RouteGateFilter imported');

    const filter = new RouteGateFilter();
    console.log('✅ RouteGateFilter created');

    const mintAddress = 'So11111111111111111111111111111111111111112';
    
    console.log('🔧 Testing with 5 second timeout...');
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('Timeout after 5 seconds')), 5000);
    });
    
    const executePromise = filter.execute(mintAddress);
    
    const result = await Promise.race([executePromise, timeoutPromise]);
    console.log('✅ Token result:', result);

  } catch (error) {
    if (error.message.includes('Timeout')) {
      console.log('❌ RouteGateFilter TIMED OUT - это проблема!');
    } else {
      console.error('❌ RouteGateFilter test failed:', error.message);
    }
    process.exit(1);
  }
}

testRouteGateFilterWithTimeout().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
