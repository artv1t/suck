#!/usr/bin/env node

console.log('💰 ПРОВЕРКА БАЛАНСА КОШЕЛЬКА...');

async function checkBalance() {
  try {
    // Импортируем компоненты
    const { RPCManager } = await import('./dist/rpc/rpcManager.js');
    const { WalletManager } = await import('./dist/wallet/walletManager.js');
    
    console.log('✅ Компоненты импортированы');

    // Создаем RPC Manager
    const rpcManager = new RPCManager();
    console.log('✅ RPC Manager создан');

    // Создаем Wallet Manager
    const walletManager = new WalletManager(rpcManager);
    console.log('✅ Wallet Manager создан');

    // Получаем информацию о кошельке
    console.log('🔍 Получение информации о кошельке...');
    const walletInfo = await walletManager.getPrimaryWallet();
    console.log('📊 Информация о кошельке:', walletInfo);

    // Получаем баланс SOL
    console.log('💎 Получение баланса SOL...');
    const solBalance = await walletManager.getTokenBalance('primary', 'So11111111111111111111111111111111111111112');
    console.log('💰 БАЛАНС SOL:', solBalance, 'SOL');

    // Получаем все токены
    console.log('🪙 Получение всех токенов...');
    const allTokens = await walletManager.getAllWalletInfo();
    console.log('📋 Все токены:', allTokens);

    // Получаем метрики
    const metrics = walletManager.getMetrics();
    console.log('📈 Метрики кошелька:', metrics);

  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

checkBalance().then(() => {
  console.log('🏁 ПРОВЕРКА ЗАВЕРШЕНА');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
