#!/usr/bin/env node

console.log('🧪 Testing RaydiumService API method directly...');

async function testRaydiumAPI() {
  try {
    const { raydiumService } = await import('./dist/services/raydiumService.js');
    console.log('✅ RaydiumService imported');

    const mintAddress = 'So11111111111111111111111111111111111111112';
    
    console.log('🔧 Testing findRaydiumPoolsViaAPI with timeout...');
    const startTime = Date.now();
    
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('API test timeout after 4 seconds')), 4000);
    });
    
    // Access private method via reflection (hack for testing)
    const apiMethod = raydiumService.findRaydiumPoolsViaAPI || raydiumService.constructor.prototype.findRaydiumPoolsViaAPI;
    
    if (!apiMethod) {
      console.log('❌ Cannot access findRaydiumPoolsViaAPI method');
      return;
    }
    
    const result = await Promise.race([apiMethod.call(raydiumService, mintAddress), timeoutPromise]);
    
    const endTime = Date.now();
    console.log('✅ API result:', result);
    console.log('✅ Time taken:', endTime - startTime, 'ms');

  } catch (error) {
    console.log('❌ API error:', error.message);
    if (error.message.includes('timeout')) {
      console.log('❌ RaydiumService API is timing out!');
    }
    process.exit(1);
  }
}

testRaydiumAPI().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
