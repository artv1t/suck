#!/usr/bin/env node

/**
 * ISOLATED LocalRouteFilter Test
 */

console.log('🧪 Testing LocalRouteFilter...');

async function testLocalRouteFilter() {
  try {
    console.log('🔧 Importing LocalRouteFilter...');
    const { LocalRouteFilter } = await import('./dist/filters/localRouteFilter.js');
    console.log('✅ LocalRouteFilter imported');

    console.log('🔧 Creating LocalRouteFilter...');
    const filter = new LocalRouteFilter();
    console.log('✅ LocalRouteFilter created');

    console.log('🔧 Testing with token...');
    const mintAddress = 'So11111111111111111111111111111111111111112';
    const result = await filter.execute(mintAddress);
    console.log('✅ Token result:', result);

    console.log('🔧 Testing getMetrics...');
    const metrics = filter.getMetrics();
    console.log('✅ Metrics:', metrics);

    console.log('✅ LocalRouteFilter test completed!');

  } catch (error) {
    console.error('❌ LocalRouteFilter test failed:', error);
    process.exit(1);
  }
}

testLocalRouteFilter().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
