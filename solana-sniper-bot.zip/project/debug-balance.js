#!/usr/bin/env node

console.log('🔍 ОТЛАДКА ПРОБЛЕМЫ С БАЛАНСОМ...');

async function debugBalance() {
  try {
    const { RPCManager } = await import('./dist/rpc/rpcManager.js');
    const { WalletManager } = await import('./dist/wallet/walletManager.js');
    const { Connection, PublicKey } = await import('@solana/web3.js');
    
    console.log('✅ Компоненты импортированы');

    // Создаем RPC Manager
    const rpcManager = new RPCManager();
    console.log('✅ RPC Manager создан');

    // Получаем здоровое соединение
    const connection = rpcManager.getHealthyConnection();
    if (!connection) {
      console.log('❌ Нет здорового соединения!');
      return;
    }
    
    console.log('✅ Здоровое соединение получено');
    console.log('🔗 RPC Endpoint:', connection.rpcEndpoint);

    // Создаем Wallet Manager
    const walletManager = new WalletManager(connection);
    console.log('✅ Wallet Manager создан');

    // Проверяем кошелек
    const primaryWallet = walletManager.getPrimaryWallet();
    if (!primaryWallet) {
      console.log('❌ Primary wallet не найден!');
      return;
    }

    console.log('✅ Primary wallet найден:', primaryWallet.publicKey.toString());

    // Тестируем прямое получение баланса через RPC
    console.log('🔍 Тестирование прямого RPC запроса...');
    try {
      const directBalance = await connection.getBalance(primaryWallet.publicKey, 'confirmed');
      const directSolBalance = directBalance / 1e9;
      console.log(`✅ Прямой RPC запрос: ${directSolBalance} SOL (${directBalance} lamports)`);
    } catch (error) {
      console.log('❌ Прямой RPC запрос failed:', error.message);
    }

    // Тестируем через WalletManager
    console.log('🔍 Тестирование через WalletManager...');
    try {
      const walletBalance = walletManager.getWalletBalance('phantom-wallet');
      console.log(`✅ WalletManager баланс: ${walletBalance} SOL`);
    } catch (error) {
      console.log('❌ WalletManager баланс failed:', error.message);
    }

    // Принудительно обновляем баланс
    console.log('🔍 Принудительное обновление баланса...');
    try {
      // Вызываем приватный метод через рефлексию
      const updateMethod = walletManager.updateWalletBalance;
      if (typeof updateMethod === 'function') {
        await updateMethod.call(walletManager, 'phantom-wallet');
        console.log('✅ Баланс обновлен');
        
        const updatedBalance = walletManager.getWalletBalance('phantom-wallet');
        console.log(`✅ Обновленный баланс: ${updatedBalance} SOL`);
      } else {
        console.log('❌ Метод updateWalletBalance не найден');
      }
    } catch (error) {
      console.log('❌ Принудительное обновление failed:', error.message);
    }

  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

debugBalance().then(() => {
  console.log('🏁 ОТЛАДКА ЗАВЕРШЕНА');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
