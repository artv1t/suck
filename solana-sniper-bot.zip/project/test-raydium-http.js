#!/usr/bin/env node

console.log('🧪 Testing Raydium HTTP API directly...');

async function testRaydiumHTTP() {
  try {
    const mintAddress = 'So11111111111111111111111111111111111111112';
    const url = `https://api.raydium.io/v2/ammV3/ammPools?mint1=${mintAddress}&mint2=So11111111111111111111111111111111111111112`;
    
    console.log('🔧 Testing HTTP request to Raydium API...');
    console.log('🔧 URL:', url);
    
    const startTime = Date.now();
    
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('HTTP timeout after 3 seconds')), 3000);
    });
    
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000);
    
    const fetchPromise = fetch(url, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'User-Agent': 'SolanaSniper/1.0'
      },
      signal: controller.signal
    });
    
    const response = await Promise.race([fetchPromise, timeoutPromise]);
    clearTimeout(timeoutId);
    
    const endTime = Date.now();
    console.log('✅ Response status:', response.status);
    console.log('✅ Time taken:', endTime - startTime, 'ms');
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ Data received:', data);
    } else {
      console.log('❌ Response not OK:', response.status, response.statusText);
    }

  } catch (error) {
    console.log('❌ HTTP error:', error.message);
    if (error.message.includes('timeout')) {
      console.log('❌ Raydium HTTP API is timing out!');
    }
    process.exit(1);
  }
}

testRaydiumHTTP().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
