#!/usr/bin/env node

console.log('🧪 Testing DexScreenerFilter...');

async function testDexScreenerFilter() {
  try {
    const { DexScreenerFilter } = await import('./dist/filters/dexScreenerFilter.js');
    console.log('✅ DexScreenerFilter imported');

    const filter = new DexScreenerFilter();
    console.log('✅ DexScreenerFilter created');

    const testToken = {
      mint: 'So11111111111111111111111111111111111111112',
      symbol: 'SOL',
      name: 'Solana',
      decimals: 9,
      supply: 1000000000,
      verified: true
    };

    console.log('🔧 Testing execute() method...');
    const result = await filter.execute(testToken);
    console.log('✅ Result:', result);

    console.log('🔧 Testing getMetrics() method...');
    const metrics = filter.getMetrics();
    console.log('✅ Metrics:', metrics);

  } catch (error) {
    console.log('❌ Error:', error.message);
    process.exit(1);
  }
}

testDexScreenerFilter().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
