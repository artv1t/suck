#!/usr/bin/env node

console.log('🧪 Testing ConsecutiveTracker...');

async function testConsecutiveTracker() {
  try {
    const { ConsecutiveTracker } = await import('./dist/filters/consecutiveTracker.js');
    console.log('✅ ConsecutiveTracker imported');

    const tracker = new ConsecutiveTracker();
    console.log('✅ ConsecutiveTracker created');

    const testToken = {
      mint: 'So11111111111111111111111111111111111111112',
      symbol: 'SOL',
      name: 'Solana',
      decimals: 9,
      supply: 1000000000,
      verified: true
    };

    console.log('🔧 Testing trackFilterResult() method...');
    const result1 = tracker.trackFilterResult(testToken.mint, true, 'TestFilter', 75);
    console.log('✅ Result 1:', result1);

    const result2 = tracker.trackFilterResult(testToken.mint, true, 'TestFilter', 80);
    console.log('✅ Result 2:', result2);

    console.log('🔧 Testing getOverallStats() method...');
    const stats = tracker.getOverallStats();
    console.log('✅ Stats:', stats);

  } catch (error) {
    console.log('❌ Error:', error.message);
    process.exit(1);
  }
}

testConsecutiveTracker().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
