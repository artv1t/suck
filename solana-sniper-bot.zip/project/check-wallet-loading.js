#!/usr/bin/env node

console.log('🔍 ПРОВЕРКА ЗАГРУЗКИ КОШЕЛЬКОВ В БОТЕ...');

async function checkWalletLoading() {
  try {
    // Импортируем компоненты
    const { RPCManager } = await import('./dist/rpc/rpcManager.js');
    const { WalletManager } = await import('./dist/wallet/walletManager.js');
    const { BotManager } = await import('./dist/core/botManager.js');
    
    console.log('✅ Компоненты импортированы');

    // Создаем RPC Manager
    const rpcManager = new RPCManager();
    console.log('✅ RPC Manager создан');

    // Создаем Wallet Manager
    const walletManager = new WalletManager(rpcManager);
    console.log('✅ Wallet Manager создан');

    // Ждем завершения обновления балансов
    console.log('⏳ Ждем завершения обновления балансов...');
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Проверяем загруженные кошельки
    console.log('🔍 ПРОВЕРКА ЗАГРУЖЕННЫХ КОШЕЛЬКОВ...');
    const allWallets = await walletManager.getAllWalletInfo();
    
    console.log('📋 ВСЕ ЗАГРУЖЕННЫЕ КОШЕЛЬКИ:');
    for (const [name, wallet] of allWallets) {
      console.log(`  🏦 ${name}:`);
      console.log(`    📍 Адрес: ${wallet.publicKey}`);
      console.log(`    💰 Баланс: ${wallet.balance} SOL`);
      console.log(`    🪙 Токены: ${wallet.tokenAccounts.size}`);
      console.log(`    ✅ Активен: ${wallet.isActive}`);
      console.log(`    🔢 Nonce: ${wallet.nonce}`);
      console.log('');
    }

    // Проверяем primary wallet
    console.log('🔍 ПРОВЕРКА PRIMARY WALLET...');
    const primaryWallet = await walletManager.getPrimaryWallet();
    
    if (primaryWallet) {
      console.log('✅ Primary wallet найден:');
      console.log(`  📍 Адрес: ${primaryWallet.publicKey}`);
      console.log(`  💰 Баланс: ${primaryWallet.balance} SOL`);
    } else {
      console.log('❌ Primary wallet НЕ найден!');
    }

    // Проверяем метрики
    const metrics = walletManager.getMetrics();
    console.log('📊 МЕТРИКИ КОШЕЛЬКОВ:');
    console.log(`  📈 Всего кошельков: ${metrics.totalWallets}`);
    console.log(`  ✅ Активных: ${metrics.activeWallets}`);
    console.log(`  💰 Общий баланс: ${metrics.totalBalance} SOL`);
    console.log(`  📊 Средний баланс: ${metrics.averageBalance} SOL`);

    // Проверяем какой кошелек будет использоваться для торговли
    console.log('🔍 КАКОЙ КОШЕЛЕК БУДЕТ ИСПОЛЬЗОВАТЬСЯ ДЛЯ ТОРГОВЛИ...');
    
    // Ищем кошелек с балансом
    let tradingWallet = null;
    for (const [name, wallet] of allWallets) {
      if (wallet.balance > 0) {
        tradingWallet = wallet;
        console.log(`✅ Кошелек для торговли: ${name}`);
        console.log(`  📍 Адрес: ${wallet.publicKey}`);
        console.log(`  💰 Баланс: ${wallet.balance} SOL`);
        break;
      }
    }

    if (!tradingWallet) {
      console.log('❌ НЕТ КОШЕЛЬКОВ С БАЛАНСОМ!');
      console.log('💡 Нужно пополнить кошельки SOL');
    }

  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

checkWalletLoading().then(() => {
  console.log('🏁 ПРОВЕРКА ЗАВЕРШЕНА');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
