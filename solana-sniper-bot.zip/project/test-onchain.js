#!/usr/bin/env node

console.log('🧪 Testing OnChainFilter...');

async function testOnChainFilter() {
  try {
    const { OnChainFilter } = await import('./dist/filters/onChainFilter.js');
    console.log('✅ OnChainFilter imported');

    const filter = new OnChainFilter();
    console.log('✅ OnChainFilter created');

    const testToken = {
      mint: 'So11111111111111111111111111111111111111112',
      symbol: 'SOL',
      name: 'Solana',
      decimals: 9,
      supply: 1000000000,
      verified: true
    };

    console.log('🔧 Testing execute() method...');
    const result = await filter.execute(testToken);
    console.log('✅ Result:', result);

    console.log('🔧 Testing getMetrics() method...');
    const metrics = filter.getMetrics();
    console.log('✅ Metrics:', metrics);

  } catch (error) {
    console.log('❌ Error:', error.message);
    process.exit(1);
  }
}

testOnChainFilter().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
