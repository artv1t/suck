#!/usr/bin/env node

console.log('🔍 ПРОВЕРКА КОШЕЛЬКА PHANTOM...');

async function checkPhantomWallet() {
  try {
    // Импортируем Solana Web3
    const { Connection, PublicKey, Keypair } = await import('@solana/web3.js');
    const bs58 = await import('bs58');
    
    console.log('✅ Solana Web3 импортирован');

    // Твой приватный ключ
    const privateKeyString = '3d1vESxeuEAGTQebx4LqT1UH1FysQtFsT397JBEzTHRfwADkp8ZsK39XAebGJJHACe4pZGs3JEBkgnPESxVtn9HC';
    
    console.log('🔑 Длина приватного ключа:', privateKeyString.length);
    
    // Проверяем формат ключа
    if (privateKeyString.length === 88) {
      console.log('✅ Формат ключа правильный (88 символов)');
    } else {
      console.log('❌ Неправильный формат ключа');
      return;
    }

    // Декодируем приватный ключ
    console.log('🔓 Декодирование приватного ключа...');
    const privateKeyBytes = bs58.default.decode(privateKeyString);
    console.log('✅ Приватный ключ декодирован, длина:', privateKeyBytes.length);

    // Создаем Keypair
    const keypair = Keypair.fromSecretKey(privateKeyBytes);
    const publicKey = keypair.publicKey;
    
    console.log('🔑 Публичный ключ:', publicKey.toString());
    console.log('🔑 Адрес кошелька:', publicKey.toString());

    // Подключаемся к Solana
    console.log('🌐 Подключение к Solana...');
    const connection = new Connection('https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4', 'confirmed');
    
    // Получаем баланс
    console.log('💰 Получение баланса...');
    const balance = await connection.getBalance(publicKey);
    const solBalance = balance / 1e9; // Конвертируем lamports в SOL
    
    console.log('💎 БАЛАНС SOL:', solBalance, 'SOL');
    console.log('💎 БАЛАНС LAMPORTS:', balance);

    // Получаем информацию об аккаунте
    console.log('📊 Получение информации об аккаунте...');
    const accountInfo = await connection.getAccountInfo(publicKey);
    
    if (accountInfo) {
      console.log('✅ Аккаунт существует');
      console.log('📊 Owner:', accountInfo.owner.toString());
      console.log('📊 Executable:', accountInfo.executable);
      console.log('📊 Rent Epoch:', accountInfo.rentEpoch);
    } else {
      console.log('❌ Аккаунт не найден');
    }

    // Получаем токены
    console.log('🪙 Получение токенов...');
    const tokenAccounts = await connection.getParsedTokenAccountsByOwner(publicKey, {
      programId: new PublicKey('TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA')
    });
    
    console.log('🪙 Количество токенов:', tokenAccounts.value.length);
    
    if (tokenAccounts.value.length > 0) {
      console.log('🪙 Токены:');
      for (const tokenAccount of tokenAccounts.value) {
        const tokenInfo = tokenAccount.account.data.parsed.info;
        console.log(`  - ${tokenInfo.mint}: ${tokenInfo.tokenAmount.uiAmount} ${tokenInfo.tokenAmount.symbol || 'tokens'}`);
      }
    } else {
      console.log('🪙 Токенов нет');
    }

    // Проверяем Wrapped SOL
    console.log('🔄 Проверка Wrapped SOL...');
    const wrappedSolMint = 'So11111111111111111111111111111111111111112';
    const wrappedSolAccounts = tokenAccounts.value.filter(account => 
      account.account.data.parsed.info.mint === wrappedSolMint
    );
    
    if (wrappedSolAccounts.length > 0) {
      console.log('✅ Wrapped SOL найден');
      const wrappedSolAmount = wrappedSolAccounts[0].account.data.parsed.info.tokenAmount.uiAmount;
      console.log('🔄 Wrapped SOL:', wrappedSolAmount);
    } else {
      console.log('❌ Wrapped SOL не найден');
    }

  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    console.error('📋 Stack trace:', error.stack);
    process.exit(1);
  }
}

checkPhantomWallet().then(() => {
  console.log('🏁 ПРОВЕРКА ЗАВЕРШЕНА');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
