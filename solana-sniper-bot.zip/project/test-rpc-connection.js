#!/usr/bin/env node

console.log('🔍 ТЕСТИРОВАНИЕ RPC СОЕДИНЕНИЙ...');

async function testRPCConnection() {
  try {
    const { Connection, PublicKey } = await import('@solana/web3.js');
    
    // Твой адрес кошелька
    const walletAddress = '66oVmpHN499TGxc2e5WY4pB1yEYqkZnwex5o88MSgiGr';
    const publicKey = new PublicKey(walletAddress);
    
    console.log('🔑 Адрес кошелька:', walletAddress);
    
    // Тестируем разные RPC endpoints
    const rpcEndpoints = [
      'https://mainnet.helius-rpc.com/?api-key=7c8922d6-1031-42c1-b4ee-bf5daa29abd4',
      'https://api.mainnet-beta.solana.com',
      'https://solana-api.projectserum.com'
    ];
    
    for (let i = 0; i < rpcEndpoints.length; i++) {
      const endpoint = rpcEndpoints[i];
      console.log(`\n🔗 Тестирование RPC ${i + 1}: ${endpoint}`);
      
      try {
        const connection = new Connection(endpoint, 'confirmed');
        
        // Тестируем получение баланса
        console.log('  💰 Получение баланса...');
        const balance = await connection.getBalance(publicKey);
        const solBalance = balance / 1e9;
        
        console.log(`  ✅ Баланс: ${solBalance} SOL (${balance} lamports)`);
        
        // Тестируем получение информации об аккаунте
        console.log('  📊 Получение информации об аккаунте...');
        const accountInfo = await connection.getAccountInfo(publicKey);
        
        if (accountInfo) {
          console.log('  ✅ Аккаунт найден');
        } else {
          console.log('  ❌ Аккаунт не найден');
        }
        
        console.log(`  ✅ RPC ${i + 1} работает!`);
        
      } catch (error) {
        console.log(`  ❌ RPC ${i + 1} не работает:`, error.message);
      }
    }
    
  } catch (error) {
    console.error('❌ ОШИБКА:', error.message);
    process.exit(1);
  }
}

testRPCConnection().then(() => {
  console.log('\n🏁 ТЕСТИРОВАНИЕ ЗАВЕРШЕНО');
  process.exit(0);
}).catch((error) => {
  console.error('💥 КРИТИЧЕСКАЯ ОШИБКА:', error);
  process.exit(1);
});
