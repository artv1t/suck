#!/usr/bin/env node

console.log('🧪 Testing RaydiumService findRaydiumPool method...');

async function testRaydiumFindPool() {
  try {
    const { raydiumService } = await import('./dist/services/raydiumService.js');
    console.log('✅ RaydiumService imported');

    const mintAddress = 'So11111111111111111111111111111111111111112';
    
    console.log('🔧 Testing findRaydiumPool with timeout...');
    const startTime = Date.now();
    
    const timeoutPromise = new Promise((_, reject) => {
      setTimeout(() => reject(new Error('FindPool test timeout after 6 seconds')), 6000);
    });
    
    // Access private method via reflection (hack for testing)
    const findPoolMethod = raydiumService.findRaydiumPool || raydiumService.constructor.prototype.findRaydiumPool;
    
    if (!findPoolMethod) {
      console.log('❌ Cannot access findRaydiumPool method');
      return;
    }
    
    const result = await Promise.race([findPoolMethod.call(raydiumService, mintAddress), timeoutPromise]);
    
    const endTime = Date.now();
    console.log('✅ FindPool result:', result);
    console.log('✅ Time taken:', endTime - startTime, 'ms');

  } catch (error) {
    console.log('❌ FindPool error:', error.message);
    if (error.message.includes('timeout')) {
      console.log('❌ RaydiumService findRaydiumPool is timing out!');
    }
    process.exit(1);
  }
}

testRaydiumFindPool().then(() => {
  console.log('🏁 Test completed');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});
