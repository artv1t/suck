#!/usr/bin/env node

/**
 * ISOLATED FilterPipeline Test
 * Tests FilterPipeline initialization without other components
 */

console.log('🧪 Starting isolated FilterPipeline test...');
console.log('🧪 This will help identify if FilterPipeline is causing the hang');

async function testFilterPipeline() {
  try {
    console.log('🔧 Importing RPCManager...');
    const { RPCManager } = await import('./src/rpc/rpcManager.js');
    console.log('✅ RPCManager imported successfully');

    console.log('🔧 Creating RPCManager instance...');
    const rpcManager = new RPCManager();
    console.log('✅ RPCManager instance created successfully');

    console.log('🔧 Importing FilterPipeline...');
    const { FilterPipeline } = await import('./src/filters/filterPipeline.js');
    console.log('✅ FilterPipeline imported successfully');

    console.log('🔧 Creating FilterPipeline instance...');
    const filterPipeline = new FilterPipeline(rpcManager);
    console.log('✅ FilterPipeline instance created successfully');

    console.log('🔧 Testing getMetrics...');
    const metrics = filterPipeline.getMetrics();
    console.log('✅ Filter metrics:', metrics);

    console.log('🔧 Testing processToken with dummy data...');
    const dummyTokenEvent = {
      mintAddress: 'So11111111111111111111111111111111111111112', // SOL mint
      symbol: 'SOL',
      name: 'Solana',
      decimals: 9,
      timestamp: Date.now(),
      source: 'test'
    };

    console.log('🔧 Processing dummy token through pipeline...');
    const result = await filterPipeline.processToken(dummyTokenEvent);
    console.log('✅ Process result:', {
      passed: result.passed,
      totalScore: result.totalScore,
      resultsCount: result.results.length
    });

    console.log('🔧 Testing consecutive stats...');
    const consecutiveStats = filterPipeline.getConsecutiveStats();
    console.log('✅ Consecutive stats:', consecutiveStats);

    console.log('✅ FilterPipeline test completed successfully!');
    console.log('🎯 FilterPipeline is NOT causing the hang');

  } catch (error) {
    console.error('❌ FilterPipeline test failed:', error);
    console.log('🎯 FilterPipeline IS causing the hang');
    process.exit(1);
  }
}

// Run the test
testFilterPipeline().then(() => {
  console.log('🏁 Test completed, exiting...');
  process.exit(0);
}).catch((error) => {
  console.error('💥 Test crashed:', error);
  process.exit(1);
});